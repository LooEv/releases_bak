# 捐助
如果您觉得nps对你有帮助，欢迎给予我们一定捐助，也是帮助nps更好的发展。

## 支付宝
![image](https://github.com/ehang-io/nps/blob/master/image/donation_zfb.png?raw=true)
## 微信
![image](https://github.com/ehang-io/nps/blob/master/image/donation_wx.png?raw=true)
