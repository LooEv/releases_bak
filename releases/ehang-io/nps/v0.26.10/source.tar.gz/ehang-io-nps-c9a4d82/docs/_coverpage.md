![logo](logo.svg)

# NPS <small>0.26.10</small>

> 一款轻量级、高性能、功能强大的内网穿透代理服务器

- 几乎支持所有协议
- 支持内网http代理、内网socks5代理、p2p等
- 简洁但功能强大的WEB管理界面
- 支持服务端、客户端同时控制
- 扩展功能强大
- 全平台兼容，一键注册为服务


[GitHub](https://github.com/ehang-io/nps/)
[开始使用](#nps)
