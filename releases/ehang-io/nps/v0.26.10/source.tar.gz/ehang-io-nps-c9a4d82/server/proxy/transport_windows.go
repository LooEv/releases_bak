// +build windows

package proxy

import (
	"ehang.io/nps/lib/conn"
)

func HandleTrans(c *conn.Conn, s *TunnelModeServer) error {
	return nil
}
